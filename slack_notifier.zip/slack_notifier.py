import json
import os
import urllib.request

def handler(event, context):
    webhook_url = os.environ["SLACK_WEBHOOK_URL"]

    for record in event.get("Records", []):
        sns_msg  = record["Sns"]
        subject  = sns_msg.get("Subject", "Lakehouse ETL Notification")
        message  = sns_msg["Message"]

        is_success = "SUCCESS" in subject.upper()
        color      = "#36a64f" if is_success else "#d9534f"
        icon       = ":white_check_mark:" if is_success else ":x:"

        payload = {
            "attachments": [{
                "color":  color,
                "title":  f"{icon}  {subject}",
                "text":   message,
                "footer": "AWS Lakehouse ETL Pipeline",
            }]
        }

        data = json.dumps(payload).encode("utf-8")
        req  = urllib.request.Request(
            webhook_url,
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        urllib.request.urlopen(req, timeout=5)
